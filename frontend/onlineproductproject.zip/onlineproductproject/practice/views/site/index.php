<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

$this->title = 'Show Data';
$this->params['breadcrumbs'][] = $this->title;

?>
<script>
    function bulkAction(a) {
        var keys = $('#grid').yiiGridView('getSelectedRows');
        window.location.href = '<?php echo Url::to(['mycontroller/bulk']); ?>&action=' + a + '&ids=' + keys.join();
    }
</script>
<h3><?= Html::encode($this->title) ?></h3>

<br>


<div class="col-lg-12">
    <?= Html::a('EXPORT', ['site/export'], [
        'class' => 'btn btn-danger'
    ]) ?><br>
    <div id="message">
        <?= Yii::$app->session->getFlash('success');
        ?>
    </div>
    <br><br>

    <?= Html::beginForm(['site/bulk'], 'post'); ?>

    <?= Html::submitButton('Send', ['class' => 'btn btn-info',]); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\CheckboxColumn'],
            'product_id',
            [
                'attribute' => 'title',
                'value' => 'product.title'
            ],
            'variant_id',
            'price',
            'inventory',

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '<div class="pull-left">{update}{delete}</div>',
                'header' => 'Action'

            ],
        ],
    ]);
    Html::endForm();


    ?>


</div>