<?php

namespace frontend\onlineproductproject\practice\controllers;

use yii\web\Controller;
use frontend\onlineproductproject\practice\models\Variant;
use yii;
use yii\data\SqlDataProvider;
use frontend\onlineproductproject\practice\models\PostSearch;

class SiteController extends Controller
{
	public function actionIndex()
	{
		$this->layout = 'main2';
		$searchModel = new PostSearch();

		$dataProvider = $searchModel->search(Yii::$app->request->queryParams);

		$dataProvider->pagination->pageSize = 5;
		// $count = Yii::$app->db2->createCommand('
		// SELECT COUNT(*) FROM  product product RIGHT JOIN variant variant on product.id = variant.product_id')->queryScalar();
		// $dataProvider = new SqlDataProvider([
		// 	'db' => 'db2',
		// 	'sql' => 'SELECT * from product product RIGHT JOIN variant variant on product.id = variant.product_id',

		// 	'totalCount' => $count,
		// 	'sort' => [
		// 		'attributes' => [
		// 			'title',
		// 			'variant_id',
		// 			'price',
		// 			'inventory',

		// 		],
		// 	],
		// 	'pagination' => [
		// 		'pageSize' => 5,
		// 	],
		// ]);


		return $this->render('index', [
			'searchModel' => $searchModel,
			'dataProvider' => $dataProvider,
		]);
	}

	public function actionDelete($id)
	{

		$model = variant::findOne($id)->delete();
		Yii::$app->session->setFlash("success", "Record deleted Successfully.");
		return $this->redirect(['index']);
	}

	public function actionUpdate($id)
	{
		$model = Variant::findOne($id);

		if ($model->load(Yii::$app->request->post()) && $model->validate()) {
			$model->save();

			Yii::$app->session->setFlash("success", "Record Updated Successfully.");

			return $this->redirect('index');
		}
		return $this->render('post-search', ['model' => $model]);
	}

	public function actionExport()
	{
		$filename = "onlineshop.csv";
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename = $filename");
		$model = Yii::$app->db2->createCommand("SELECT * from product product RIGHT JOIN variant variant on product.id = variant.product_id")->queryAll();
		$filepath = fopen("php://output", 'w');
		$header = array_keys($model[0]);
		fputcsv($filepath, $header);
		foreach ($model as $v) {
			fputcsv($filepath, $v);
		}
	}
	public function actionBulk()
	{
		$action = Yii::$app->request->post('action');
		$selection = (array)Yii::$app->request->post('selection');
		foreach ($selection as $id) {
			$e = Variant::findOne((int)$id);
			echo $id;
			// echo $id;
			// $filename = "onlineshop.csv";
			// header("Content-type: text/csv");
			// header("Content-Disposition: attachment; filename = $filename");
			// $model = Yii::$app->db2->createCommand("SELECT `variant_id`,`price`,`inventory`,`title` from product product RIGHT JOIN variant variant on product.id = variant.id")->queryAll();
			// $filepath = fopen("php://output", 'w');
			// $header = array_keys($model[0]);
			// fputcsv($filepath, $header);
			// foreach ($model as $v) {
			// 	fputcsv($filepath, $v);
			// }
		}
	}
}
