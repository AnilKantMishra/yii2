<?php

namespace frontend\onlineproductproject\practice\models;

use yii\data\ActiveDataProvider;
use yii;

class PostSearch extends Variant
{
    public $id;
    public $product_id;
    public $title;
    public $variant_id;
    public $price;
    public $inventory;

    public function rules()
    {
        return [
            [['title'], 'string'],
            [['variant_id'], 'integer'],


            [['inventory'], 'integer'],
            [['price', 'variant_id', 'title', 'inventory'], 'safe'],
            // [['product_id', 'title', 'variant_id', 'price', 'inventory'], 'required'],
        ];
    }

    public function search($params)
    {
        $query = Variant::find();
        $query->joinWith('product');
        $count = Yii::$app->db2->createCommand('
		select max,min from variant as v join (select `product_id`,price,max(price) as max,min(price) as min from variant group by product_id ) a where v.product_id = a.product_id')->queryScalar();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            // 'sql' => $count


        ]);

        // No search? Then return data Provider
        $this->load($params);
        if (!$this->validate()) {
            return $dataProvider;
        }
        $query->andFilterWhere(['=', 'title', $this->title])
            ->andFilterWhere(['like', 'variant_id', $this->variant_id])
            ->andFilterWhere(['like', 'price', $this->price])
            ->andFilterWhere(['like', 'inventory', $this->inventory]);

        return $dataProvider;
    }
}
