<?php


namespace frontend\onlineproductproject\practice\models;


use yii;

class Product extends \yii\db\ActiveRecord
{
    public static function getDb()
    {
        return Yii::$app->db2;
    }
    public static function tableName()
    {
        // $m = registered::find()->all();
        // Yii::$app->cache->set('data',$m);
        // $n = Yii::$app->cache->get('data'),
        return 'product';
    }

    public function rules()
    {
        return [
            [['id', 'product_id', 'title', 'created_at'], 'required'],
            [['id'], 'integer'],
            [['product_id'], 'integer'],
            [['title'], 'string'],
            [['created_at'], 'date'],
        ];
    }
}
