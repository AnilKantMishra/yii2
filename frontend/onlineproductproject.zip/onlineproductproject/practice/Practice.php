<?php

namespace frontend\onlineproductproject\practice;

use Yii;

class Practice extends \yii\base\Module
{
	public $controllerNamespace = 'frontend\onlineproductproject\practice\controllers';

	public $defaultRoute = 'site';
	public $layout = 'main2';
	public function init()
	{
		// die("die...sdfsad");
		parent::init();
	}
}
